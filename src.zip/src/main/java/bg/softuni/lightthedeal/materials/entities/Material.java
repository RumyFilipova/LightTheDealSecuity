package bg.softuni.lightthedeal.materials.entities;

import bg.softuni.lightthedeal.user.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.UUID;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "materials")
public class Material {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private String name;// name(cable, circuit breaker)

    @Column(nullable = false)
    private String type;// type(3A, 16A)

    @Column
    private String description;//additional clarification such as type of assembly

    @Column
    private String brand;// Schneider, Siemens, Muller

    @Column(name = "single_price",nullable = false)
    private BigDecimal singlePrice;

    @Column(name = "quantity",nullable = false)
    private Double quantity;

    @Enumerated(EnumType.STRING)
    @Column
    private Unit unit;

    @Enumerated(EnumType.STRING)
    @Column
    private Category category;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}
